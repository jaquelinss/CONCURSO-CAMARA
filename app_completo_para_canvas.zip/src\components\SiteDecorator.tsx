import { useEffect, useState, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { useReward } from '../contexts/RewardContext';
import { useGlobalSplitScreen } from '../hooks/useGlobalSplitScreen';
import Draggable from 'react-draggable';
import { StickerImage } from './StickerImage';
import { Unlock, Trash2, Plus, Minus } from 'lucide-react';

interface PlacedSticker {
  id: string;
  stickerId: string;
  customUrl?: string;
  x: number;
  y: number;
  isLocked: boolean;
  scale?: number;
}

const STICKERS_DEFS: Record<string, string> = {
  '1': '/stickers/1.png',
  '2': '/stickers/2.png',
  '3': '/stickers/3.png',
  '4': '/stickers/4.png',
  '5': '/stickers/5.png',
  '6': '/stickers/6.png',
  '7': '/stickers/7.png',
  '8': '/stickers/8.png',
  '9': '/stickers/9.png',
  '10': '/stickers/10.png',
  '11': '/stickers/11.png',
};

export default function SiteDecorator() {
  const { user } = useAuth();
  const location = useLocation();
  const { activeStamper } = useReward();
  const { splitMode, splitWidth, splitSide } = useGlobalSplitScreen();
  
  const [stickers, setStickers] = useState<PlacedSticker[]>([]);
  const [splitStickers, setSplitStickers] = useState<PlacedSticker[]>([]);

  // Per-route document ID
  const docId = `decorations_${location.pathname.replace(/[^a-zA-Z0-9]/g, '_') || 'root'}`;
  const splitDocId = 'decorations_global_split_workspace';

  // Keep a ref to always have the latest stickers (avoids stale closure)
  const stickersRef = useRef<PlacedSticker[]>(stickers);
  const splitStickersRef = useRef<PlacedSticker[]>(splitStickers);
  
  useEffect(() => { stickersRef.current = stickers; }, [stickers]);
  useEffect(() => { splitStickersRef.current = splitStickers; }, [splitStickers]);

  // Also keep docId in a ref so the click handler always uses the current one
  const docIdRef = useRef(docId);
  useEffect(() => { docIdRef.current = docId; }, [docId]);

  // Fetch stickers for current route
  useEffect(() => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'settings', docId);
    
    const unsubscribe = onSnapshot(docRef, (snap) => {
      if (snap.exists()) {
        setStickers(snap.data().stickers || []);
      } else {
        setStickers([]);
      }
    });

    return unsubscribe;
  }, [user, docId]);

  // Fetch stickers for split workspace
  useEffect(() => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'settings', splitDocId);
    
    const unsubscribe = onSnapshot(docRef, (snap) => {
      if (snap.exists()) {
        setSplitStickers(snap.data().stickers || []);
      } else {
        setSplitStickers([]);
      }
    });

    return unsubscribe;
  }, [user, splitDocId]);

  // Handle global click to place stamper
  useEffect(() => {
    if (!activeStamper || !user) {
      console.log('[STAMPER] useEffect: no activeStamper or user, skipping listener registration. activeStamper:', activeStamper, 'user:', !!user);
      return;
    }

    console.log('[STAMPER] useEffect: REGISTERING click listener. activeStamper:', activeStamper);

    const handleGlobalClick = async (e: MouseEvent) => {
      console.log('[STAMPER] Click detected!', 'target:', (e.target as HTMLElement).tagName, (e.target as HTMLElement).className?.substring(0, 80));
      
      // Ignore clicks on interactive UI elements (but allow most page areas)
      const target = e.target as HTMLElement;
      if (target.closest('[role="dialog"], [role="menu"], .modal, .reward-shop, .whiteboard-toolbar, .whiteboard-sidebar, .palette-popover')) {
        console.log('[STAMPER] BLOCKED: dialog/modal/toolbar');
        return;
      }
      if (target.closest('input, textarea, select')) {
        console.log('[STAMPER] BLOCKED: input/textarea/select');
        return;
      }
      const closestButton = target.closest('button');
      if (closestButton) {
        const rect = closestButton.getBoundingClientRect();
        if (rect.width < 200 && rect.height < 100) {
          console.log('[STAMPER] BLOCKED: small button', rect.width, 'x', rect.height);
          return;
        }
      }

      console.log('[STAMPER] Placing sticker at', e.pageX, e.pageY);

      let isInSplitSpace = false;
      let localX = e.pageX;
      let localY = e.pageY;

      if (splitMode) {
        const boundaryX = splitSide === 'right' 
          ? window.innerWidth * ((100 - splitWidth) / 100)
          : window.innerWidth * (splitWidth / 100);

        if (splitSide === 'right' && e.clientX >= boundaryX) {
          isInSplitSpace = true;
          localX = e.clientX - boundaryX;
          localY = e.clientY;
        } else if (splitSide === 'left' && e.clientX <= boundaryX) {
          isInSplitSpace = true;
          localX = e.clientX;
          localY = e.clientY;
        }
      }

      const newSticker: PlacedSticker = {
        id: `decor_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
        stickerId: activeStamper.stickerId,
        x: localX - 64,
        y: localY - 64,
        isLocked: false
      };
      
      if (activeStamper.customUrl) {
        newSticker.customUrl = activeStamper.customUrl;
      }

      try {
        if (isInSplitSpace) {
          const newStickers = [...splitStickersRef.current, newSticker];
          setSplitStickers(newStickers);
          const docRef = doc(db, 'users', user.uid, 'settings', splitDocId);
          await setDoc(docRef, { stickers: newStickers }, { merge: true });
          console.log('[STAMPER] SUCCESS: sticker placed in split space');
        } else {
          const currentDocId = docIdRef.current;
          const newStickers = [...stickersRef.current, newSticker];
          console.log('[STAMPER] Saving to docId:', currentDocId, 'total stickers:', newStickers.length);
          setStickers(newStickers);
          const docRef = doc(db, 'users', user.uid, 'settings', currentDocId);
          await setDoc(docRef, { stickers: newStickers }, { merge: true });
          console.log('[STAMPER] SUCCESS: sticker placed on main route');
        }
      } catch (err) {
        console.error('[STAMPER] ERROR placing sticker:', err);
      }
    };

    // Use capture phase to ensure the click is received before any stopPropagation
    window.addEventListener('click', handleGlobalClick, true);
    return () => {
      console.log('[STAMPER] useEffect cleanup: REMOVING click listener');
      window.removeEventListener('click', handleGlobalClick, true);
    };
  }, [user, activeStamper, splitMode, splitWidth, splitSide]);

  // Handle remove sticker via global event
  useEffect(() => {
    if (!user) return;
    const handleRemoveSticker = async (e: Event) => {
      const customEvent = e as CustomEvent<{ instanceId: string }>;
      const { instanceId } = customEvent.detail;
      
      const current = stickersRef.current;
      if (!current.some(s => s.id === instanceId)) return;

      const newStickers = current.filter(s => s.id !== instanceId);
      setStickers(newStickers);
      
      const docRef = doc(db, 'users', user.uid, 'settings', docIdRef.current);
      await setDoc(docRef, { stickers: newStickers }, { merge: true });
    };

    window.addEventListener('remove-sticker', handleRemoveSticker);
    return () => window.removeEventListener('remove-sticker', handleRemoveSticker);
  }, [user]);

  const updateSticker = async (id: string, updates: Partial<PlacedSticker>) => {
    if (!user) return;
    const updated = stickersRef.current.map(s => s.id === id ? { ...s, ...updates } : s);
    setStickers(updated);
    const docRef = doc(db, 'users', user.uid, 'settings', docIdRef.current);
    await setDoc(docRef, { stickers: updated }, { merge: true });
  };

  const removeSticker = async (id: string) => {
    if (!user) return;
    const newStickers = stickersRef.current.filter(s => s.id !== id);
    setStickers(newStickers);
    const docRef = doc(db, 'users', user.uid, 'settings', docIdRef.current);
    await setDoc(docRef, { stickers: newStickers }, { merge: true });
  };

  // Split Workspace Handlers
  const updateSplitSticker = async (id: string, updates: Partial<PlacedSticker>) => {
    if (!user) return;
    const updated = splitStickersRef.current.map(s => s.id === id ? { ...s, ...updates } : s);
    setSplitStickers(updated);
    const docRef = doc(db, 'users', user.uid, 'settings', splitDocId);
    await setDoc(docRef, { stickers: updated }, { merge: true });
  };

  const removeSplitSticker = async (id: string) => {
    if (!user) return;
    const newStickers = splitStickersRef.current.filter(s => s.id !== id);
    setSplitStickers(newStickers);
    const docRef = doc(db, 'users', user.uid, 'settings', splitDocId);
    await setDoc(docRef, { stickers: newStickers }, { merge: true });
  };

  return (
    <>
      {/* Main Route Stickers */}
      <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 9990 }}>
        {stickers.map(sticker => (
          <DraggableSticker 
            key={sticker.id}
            sticker={sticker}
            onUpdate={(updates) => updateSticker(sticker.id, updates)}
            onRemove={() => removeSticker(sticker.id)}
          />
        ))}
      </div>

      {/* Split Workspace Stickers */}
      {splitMode && (
        <div 
          className="fixed top-0 bottom-0 pointer-events-none" 
          style={{ 
            zIndex: 9990,
            width: `${splitWidth}%`, 
            [splitSide === 'right' ? 'right' : 'left']: 0 
          }}
        >
          {splitStickers.map(sticker => (
            <DraggableSticker 
              key={sticker.id}
              sticker={sticker}
              onUpdate={(updates) => updateSplitSticker(sticker.id, updates)}
              onRemove={() => removeSplitSticker(sticker.id)}
            />
          ))}
        </div>
      )}
    </>
  );
}

function DraggableSticker({ 
  sticker, 
  onUpdate,
  onRemove
}: { 
  sticker: PlacedSticker; 
  onUpdate: (u: Partial<PlacedSticker>) => void;
  onRemove: () => void;
}) {
  const nodeRef = useRef<HTMLDivElement>(null);
  const [showMenu, setShowMenu] = useState(false);
  const url = sticker.customUrl || STICKERS_DEFS[sticker.stickerId];
  const currentScale = sticker.scale || 1;

  const handleScale = (delta: number) => {
    onUpdate({ scale: Math.max(0.5, Math.min(3, currentScale + delta)) });
  };
  
  // Close menu when clicking anywhere else
  useEffect(() => {
    if (!showMenu) return;
    const close = () => setShowMenu(false);
    window.addEventListener('click', close);
    return () => window.removeEventListener('click', close);
  }, [showMenu]);

  if (!url) return null;

  return (
    <Draggable
      nodeRef={nodeRef}
      position={{ x: sticker.x, y: sticker.y }}
      disabled={sticker.isLocked}
      onStart={(e) => {
        // Prevent browser scroll on mobile while dragging
        if (e.type === 'touchstart') {
          e.preventDefault();
        }
      }}
      onStop={(_, data) => onUpdate({ x: data.x, y: data.y })}
    >
      <div 
        ref={nodeRef} 
        className="absolute inline-block pointer-events-auto"
        style={{ touchAction: sticker.isLocked ? 'auto' : 'none' }}
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setShowMenu(!showMenu);
        }}
      >
        <StickerImage 
          src={url}
          className={`w-20 h-20 md:w-32 md:h-32 object-contain drop-shadow-md transition-opacity ${sticker.isLocked ? 'opacity-90' : 'opacity-100 cursor-move'}`}
          style={{ transform: `scale(${currentScale})`, transformOrigin: 'center' }}
        />
        
        {/* Right-click context menu */}
        {showMenu && (
          <div 
            className="absolute bg-white/95 backdrop-blur-md shadow-xl border border-gray-200 rounded-xl p-1.5 flex flex-col gap-1 pointer-events-auto z-50 animate-in fade-in"
            style={{ 
              top: `calc(100% + ${(currentScale - 1) * 50}% + 12px)`, 
              left: '50%', 
              transform: 'translateX(-50%)' 
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {!sticker.isLocked && (
              <button 
                onClick={(e) => { e.stopPropagation(); onUpdate({ isLocked: true }); setShowMenu(false); }}
                className="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 rounded-lg text-gray-700 text-xs font-medium transition-colors whitespace-nowrap"
              >
                <Unlock className="w-3.5 h-3.5" />
                Travar no fundo
              </button>
            )}
            {sticker.isLocked && (
              <button 
                onClick={(e) => { e.stopPropagation(); onUpdate({ isLocked: false }); setShowMenu(false); }}
                className="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 rounded-lg text-gray-700 text-xs font-medium transition-colors whitespace-nowrap"
              >
                <Unlock className="w-3.5 h-3.5" />
                Destravar
              </button>
            )}
            {!sticker.isLocked && (
              <>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleScale(0.2); }}
                  className="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 rounded-lg text-gray-700 text-xs font-medium transition-colors whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Aumentar
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); handleScale(-0.2); }}
                  className="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-100 rounded-lg text-gray-700 text-xs font-medium transition-colors whitespace-nowrap"
                >
                  <Minus className="w-3.5 h-3.5" />
                  Diminuir
                </button>
              </>
            )}
            <button 
              onClick={(e) => { e.stopPropagation(); onRemove(); setShowMenu(false); }}
              className="flex items-center gap-2 px-3 py-1.5 hover:bg-red-50 text-red-600 rounded-lg text-xs font-medium transition-colors whitespace-nowrap"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Remover
            </button>
          </div>
        )}
      </div>
    </Draggable>
  );
}

