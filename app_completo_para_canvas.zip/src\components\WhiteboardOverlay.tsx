import { useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Eraser, Trash2, X, Undo2, Redo2, Minus, Plus, Maximize2, Minimize2, GripHorizontal, ChevronLeft, ChevronRight, FilePlus, PanelTop, Settings2, Focus, MousePointer2, Book, Highlighter } from 'lucide-react';
import { getStroke } from 'perfect-freehand';
import Draggable from 'react-draggable';
import { useAuth } from '../contexts/AuthContext';
import { doc, getDoc, setDoc, collection, query, getDocs, orderBy, where, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import localforage from 'localforage';
import { useReward } from '../contexts/RewardContext';

interface StrokePoint {
  x: number;
  y: number;
  pressure: number;
}

interface Stroke {
  points: StrokePoint[];
  color: string;
  width: number;
  isEraser: boolean;
  isHighlighter?: boolean;
  isSticker?: boolean;
  stickerNumber?: number;
  isRewardSticker?: boolean;
  rewardStickerId?: string;
  rewardCustomUrl?: string;
  rewardInstanceId?: string;
}

interface PenPreset {
  id: string;
  color: string;
  width: number;
}

interface HighlighterPreset {
  id: string;
  color: string;
  width: number;
}

interface EraserPreset {
  id: string;
  type: 'normal' | 'stroke';
  width: number;
}

const COLORS = ['#000000', '#ffffff', '#ef4444', '#3b82f6', '#22c55e', '#eab308', '#a855f7', '#f97316'];

const STICKERS_DEFS: Record<string, string> = {
  '1': '/stickers/1.png',
  '2': '/stickers/2.png',
  '3': '/stickers/3.png',
  '4': '/stickers/4.png',
  '5': '/stickers/5.png',
  '6': '/stickers/6.png',
  '7': '/stickers/7.png',
  '8': '/stickers/8.png',
  '9': '/stickers/9.png',
  '10': '/stickers/10.png',
  '11': '/stickers/11.png',
};

import NotebooksManager from './NotebooksManager';
import type { Notebook } from '../types/notebook';

export default function WhiteboardOverlay() {
  const { user } = useAuth();
  const { activeStamper } = useReward();
  const [active, setActive] = useState(false);
  
  // Notebooks
  const [showNotebooksManager, setShowNotebooksManager] = useState(false);
  const [activeNotebook, setActiveNotebook] = useState<Notebook | null>(null);

  // Modos de Lousa
  const [windowMode, setWindowMode] = useState<'fullscreen' | 'floating'>('fullscreen');
  const [scrollY, setScrollY] = useState(0);
  const [mode, setMode] = useState<'transparent' | 'lined' | 'grid' | 'dotted'>('lined');
  
  // Menu Principal Original
  const [tool, setTool] = useState<'pen' | 'eraser' | 'pointer' | 'highlighter' | 'sticker'>('pen');
  const previousTool = useRef<'pen' | 'eraser' | 'highlighter' | 'sticker'>('pen');

  useEffect(() => {
    if (tool !== 'pointer') {
      previousTool.current = tool as 'pen' | 'eraser' | 'highlighter';
    }
  }, [tool]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignorar se o usuário estiver digitando em um input
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || (e.target as HTMLElement).isContentEditable) return;

      // Atalho V ou Escape para alternar para o mouse
      if (e.key.toLowerCase() === 'v' || e.key === 'Escape') {
        setTool(prev => prev === 'pointer' ? previousTool.current : 'pointer');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);


  // Sidebar e Presets
  const [penPresets, setPenPresets] = useState<PenPreset[]>([{ id: 'p1', color: '#000000', width: 4 }]);
  const [highlighterPresets, setHighlighterPresets] = useState<HighlighterPreset[]>([{ id: 'h1', color: '#fef08a', width: 20 }]);
  const [eraserPresets, setEraserPresets] = useState<EraserPreset[]>([{ id: 'e1', type: 'normal', width: 16 }]);
  const [activePenId, setActivePenId] = useState<string>('p1');
  const [activeHighlighterId, setActiveHighlighterId] = useState<string>('h1');
  const [activeEraserId, setActiveEraserId] = useState<string>('e1');
  const [sidebarMode, setSidebarMode] = useState<'fixed' | 'floating' | 'hidden'>('fixed');
  const [editingPreset, setEditingPreset] = useState<string | null>(null);
  const [showSidebarSettings, setShowSidebarSettings] = useState(false);

  // Derived values from active presets (single source of truth)
  const activePen = penPresets.find(p => p.id === activePenId) || penPresets[0];
  const activeHighlighter = highlighterPresets.find(p => p.id === activeHighlighterId) || highlighterPresets[0];
  const activeEraser = eraserPresets.find(p => p.id === activeEraserId) || eraserPresets[0];
  const color = tool === 'pen' ? activePen.color : tool === 'highlighter' ? activeHighlighter.color : '#000000';
  const strokeWidth = tool === 'pen' ? activePen.width : tool === 'highlighter' ? activeHighlighter.width : activeEraser.width;


  // Páginas do Caderninho
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [strokesByPage, setStrokesByPage] = useState<Record<number, Stroke[]>>({ 1: [] });
  const [redoStackByPage, setRedoStackByPage] = useState<Record<number, Stroke[]>>({ 1: [] });
  const [isLoaded, setIsLoaded] = useState(false);
  // Tracks which context ('draft' or notebook ID) the current strokesByPage was loaded for.
  // Auto-save only proceeds when this matches the current context, preventing cross-contamination.
  const loadedForRef = useRef<string | null>(null);

  // Carregar dados iniciais (Rascunho ou Caderno)
  useEffect(() => {
    // Immediately invalidate to prevent auto-save from firing with stale data
    loadedForRef.current = null;
    setIsLoaded(false);

    const loadData = async () => {
      const contextId = activeNotebook?.id || 'draft';

      if (activeNotebook && user) {
        // Load from Firebase
        try {
          const q = query(collection(db, 'users', user.uid, 'notebooks', activeNotebook.id, 'pages'));
          const snap = await getDocs(q);
          const loadedStrokes: Record<number, Stroke[]> = {};
          snap.forEach(d => {
            const data = d.data();
            const pageNum = parseInt(d.id.replace('page_', ''));
            if (!isNaN(pageNum) && data.strokes) {
              loadedStrokes[pageNum] = JSON.parse(data.strokes);
            }
          });
          if (Object.keys(loadedStrokes).length > 0) {
            setStrokesByPage(loadedStrokes);
          } else {
            setStrokesByPage({ 1: [] });
          }
          setTotalPages(activeNotebook.totalPages || 1);
          setCurrentPage((activeNotebook as any).lastPage || 1);
        } catch (e) {
          console.error('Erro ao carregar caderno:', e);
          setStrokesByPage({ 1: [] });
        }
      } else {
        // Load Quick Draft from IndexedDB
        try {
          const savedStrokes = await localforage.getItem<Record<number, Stroke[]>>('whiteboard-quick-draft');
          if (savedStrokes && Object.keys(savedStrokes).length > 0) {
            setStrokesByPage(savedStrokes);
            const maxPage = Math.max(...Object.keys(savedStrokes).map(Number));
            if (maxPage > 1) {
              setTotalPages(maxPage);
            } else {
              setTotalPages(1);
            }
            setCurrentPage(1);
          } else {
            setStrokesByPage({ 1: [] });
            setTotalPages(1);
            setCurrentPage(1);
          }
        } catch (e) {
          console.error(e);
          setStrokesByPage({ 1: [] });
        }
      }
      setRedoStackByPage({ 1: [] });
      loadedForRef.current = contextId;
      setIsLoaded(true);
    };

    loadData();
  }, [activeNotebook, user]);

  // Handle remove sticker
  useEffect(() => {
    const handleRemoveSticker = (e: Event) => {
      const customEvent = e as CustomEvent<{ instanceId: string }>;
      const { instanceId } = customEvent.detail;
      
      setStrokesByPage(prev => {
        let changed = false;
        const newStrokesByPage = { ...prev };
        
        for (const pageStr in prev) {
          const page = parseInt(pageStr);
          const strokes = prev[page];
          const hasSticker = strokes.some(s => s.rewardInstanceId === instanceId);
          if (hasSticker) {
            newStrokesByPage[page] = strokes.filter(s => s.rewardInstanceId !== instanceId);
            changed = true;
          }
        }
        
        return changed ? newStrokesByPage : prev;
      });
    };

    window.addEventListener('remove-sticker', handleRemoveSticker);
    return () => window.removeEventListener('remove-sticker', handleRemoveSticker);
  }, []);

  // Auto-save: Salvar no IndexedDB ou Firebase sempre que mudar
  useEffect(() => {
    if (!isLoaded) return;

    // Guard: only save if the current context matches what was loaded.
    // This prevents saving notebook strokes as quick-draft (or vice-versa) during mode switches.
    const currentContextId = activeNotebook?.id || 'draft';
    if (loadedForRef.current !== currentContextId) return;

    if (activeNotebook && user) {
      // Save current page to Firebase
      const currentStrokes = strokesByPage[currentPage] || [];
      const pageRef = doc(db, 'users', user.uid, 'notebooks', activeNotebook.id, 'pages', `page_${currentPage}`);
      setDoc(pageRef, {
        strokes: JSON.stringify(currentStrokes),
        updatedAt: Date.now()
      }, { merge: true }).catch(console.error);

      // Se o total de páginas aumentou ou a página mudou, atualiza no caderno principal
      setDoc(doc(db, 'users', user.uid, 'notebooks', activeNotebook.id), {
        totalPages: Math.max(totalPages, activeNotebook.totalPages || 1),
        lastPage: currentPage,
        updatedAt: Date.now()
      }, { merge: true }).catch(console.error);
      
      if (totalPages > (activeNotebook.totalPages || 1)) {
        setActiveNotebook(prev => prev ? { ...prev, totalPages } : prev);
      }
    } else {
      // Save Quick Draft to IndexedDB
      localforage.setItem('whiteboard-quick-draft', strokesByPage).catch(console.error);
    }
  }, [strokesByPage, isLoaded, currentPage, totalPages, activeNotebook, user]);

  const [isDrawing, setIsDrawing] = useState(false);
  
  const bgCanvasRef = useRef<HTMLCanvasElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const currentStrokeRef = useRef<Stroke | null>(null);
  const animFrameRef = useRef<number>(0);
  const isStraightLineRef = useRef(false);

  // Floating Window Size
  const savedSize = (() => { try { return JSON.parse(localStorage.getItem('wb_size') || 'null'); } catch { return null; } })();
  const [size, setSize] = useState({ 
    w: savedSize?.w || Math.min(600, window.innerWidth - 40), 
    h: savedSize?.h || Math.min(800, window.innerHeight - 100) 
  });
  const resizeRef = useRef<{ startX: number; startY: number; startW: number; startH: number } | null>(null);

  const savedPos = (() => {
    try {
      const p = JSON.parse(localStorage.getItem('wb_pos') || 'null');
      if (p) return p;
    } catch {}
    // Default: center on screen
    const w = savedSize?.w || Math.min(600, window.innerWidth - 40);
    const h = savedSize?.h || Math.min(800, window.innerHeight - 100);
    return { x: Math.max(0, Math.round((window.innerWidth - w) / 2)), y: Math.max(0, Math.round((window.innerHeight - h) / 2)) };
  })();

  // Carregar/Salvar Settings do Firestore
  useEffect(() => {
    if (!user) return;
    getDoc(doc(db, 'users', user.uid, 'settings', 'whiteboard')).then(d => {
      if (d.exists()) {
        const data = d.data();
        if (data.penPresets && data.penPresets.length > 0) setPenPresets(data.penPresets);
        if (data.highlighterPresets && data.highlighterPresets.length > 0) setHighlighterPresets(data.highlighterPresets);
        if (data.eraserPresets && data.eraserPresets.length > 0) setEraserPresets(data.eraserPresets);
        if (data.sidebarMode) setSidebarMode(data.sidebarMode);
      }
    });
  }, [user]);

  const saveSettings = useCallback((newPens: PenPreset[], newHighlighters: HighlighterPreset[], newErasers: EraserPreset[], newSidebarMode: string) => {
    if (!user) return;
    setDoc(doc(db, 'users', user.uid, 'settings', 'whiteboard'), {
      penPresets: newPens,
      highlighterPresets: newHighlighters,
      eraserPresets: newErasers,
      sidebarMode: newSidebarMode
    }, { merge: true }).catch(console.error);
  }, [user]);

  const updatePenPreset = (id: string, updates: Partial<PenPreset>) => {
    setPenPresets(prev => {
      const newPens = prev.map(p => p.id === id ? { ...p, ...updates } : p);
      saveSettings(newPens, highlighterPresets, eraserPresets, sidebarMode);
      return newPens;
    });
  };

  const updateEraserPreset = (id: string, updates: Partial<EraserPreset>) => {
    setEraserPresets(prev => {
      const newErasers = prev.map(p => p.id === id ? { ...p, ...updates } : p);
      saveSettings(penPresets, highlighterPresets, newErasers, sidebarMode);
      return newErasers;
    });
  };

  const addPenPreset = () => {
    if (penPresets.length >= 5) return;
    const newId = `p${Date.now()}`;
    const newPens = [...penPresets, { id: newId, color: '#000000', width: 4 }];
    setPenPresets(newPens);
    saveSettings(newPens, highlighterPresets, eraserPresets, sidebarMode);
    setActivePenId(newId);
    setTool('pen');
  };

  
  const updateHighlighterPreset = (id: string, updates: Partial<HighlighterPreset>) => {
    setHighlighterPresets(prev => {
      const newHL = prev.map(p => p.id === id ? { ...p, ...updates } : p);
      saveSettings(penPresets, newHL, eraserPresets, sidebarMode);
      return newHL;
    });
  };

  const addHighlighterPreset = () => {
    if (highlighterPresets.length >= 5) return;
    const newId = `h${Date.now()}`;
    const newHL = [...highlighterPresets, { id: newId, color: '#fef08a', width: 20 }];
    setHighlighterPresets(newHL);
    saveSettings(penPresets, newHL, eraserPresets, sidebarMode);
    setActiveHighlighterId(newId);
    setTool('highlighter');
  };

  const deleteHighlighterPreset = (id: string) => {
    if (highlighterPresets.length <= 1) return;
    const newHL = highlighterPresets.filter(p => p.id !== id);
    setHighlighterPresets(newHL);
    if (activeHighlighterId === id) setActiveHighlighterId(newHL[0].id);
    setEditingPreset(null);
    saveSettings(penPresets, newHL, eraserPresets, sidebarMode);
  };

  const addEraserPreset = () => {
    if (eraserPresets.length >= 2) return;
    const newId = `e${Date.now()}`;
    const newErasers: EraserPreset[] = [...eraserPresets, { id: newId, type: 'stroke', width: 16 }];
    setEraserPresets(newErasers);
    saveSettings(penPresets, highlighterPresets, newErasers, sidebarMode);
    setActiveEraserId(newId);
    setTool('eraser');
  };

  const deletePenPreset = (id: string) => {
    if (penPresets.length <= 1) return;
    const newPens = penPresets.filter(p => p.id !== id);
    setPenPresets(newPens);
    if (activePenId === id) setActivePenId(newPens[0].id);
    setEditingPreset(null);
    saveSettings(newPens, highlighterPresets, eraserPresets, sidebarMode);
  };


  // Listen for global toggle events
  const lastActiveNotebookRef = useRef<Notebook | null>(null);

  useEffect(() => {
    const handleTransparent = () => {
      setActive(true);
      setMode('transparent');
      setWindowMode('fullscreen');
      setActiveNotebook(prev => {
        if (prev) lastActiveNotebookRef.current = prev;
        return null;
      });
    };
    const handleNotebook = () => {
      setActive(true);
      setMode('lined');
      setWindowMode('floating');
      setActiveNotebook(prev => {
        if (!prev && lastActiveNotebookRef.current) {
          return lastActiveNotebookRef.current;
        }
        return prev;
      });
    };
    const handleToggle = () => setActive(prev => !prev);
    window.addEventListener('toggle-whiteboard-transparent', handleTransparent);
    window.addEventListener('toggle-whiteboard-notebook', handleNotebook);
    window.addEventListener('toggle-whiteboard', handleToggle);
    return () => {
      window.removeEventListener('toggle-whiteboard-transparent', handleTransparent);
      window.removeEventListener('toggle-whiteboard-notebook', handleNotebook);
      window.removeEventListener('toggle-whiteboard', handleToggle);
    };
  }, []);

  // Load all notebooks for sidebar navigation
  useEffect(() => {
    if (!user) return;
    const loadAllNotebooks = async () => {
      try {
        const q2 = query(collection(db, 'users', user.uid, 'notebooks'), orderBy('updatedAt', 'desc'));
        const snap = await getDocs(q2);
        const loaded: Notebook[] = [];
        snap.forEach(d => loaded.push({ id: d.id, ...d.data() } as Notebook));
        if (loaded.length > 0) {
          setActiveNotebook(prev => {
            if (prev) return prev;
            // Define lastActiveNotebookRef para podermos restaurar depois
            lastActiveNotebookRef.current = loaded[0];
            
            // Se o usuário já abriu a lousa transparente, não defina o activeNotebook
            // (Isso evita carregar o caderno por cima da lousa transparente no load inicial)
            const isTransparentEvent = window.document.querySelector('.whiteboard-transparent-active');
            if (isTransparentEvent) return null;
            
            return loaded[0];
          });
        }
      } catch (e) {
        console.error('Erro ao carregar lista de cadernos:', e);
      }
    };
    loadAllNotebooks();
  }, [user, showNotebooksManager]);


  const strokes = strokesByPage[currentPage] || [];
  const redoStack = redoStackByPage[currentPage] || [];

  // Redimensionar Canvas
  useEffect(() => {
    if (!active || !canvasRef.current || !bgCanvasRef.current || !containerRef.current) return;
    const canvas = canvasRef.current;
    const bgCanvas = bgCanvasRef.current;
    const container = containerRef.current;
    
    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = container.getBoundingClientRect();
      
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      canvas.style.width = `${rect.width}px`;
      canvas.style.height = `${rect.height}px`;
      
      bgCanvas.width = rect.width * dpr;
      bgCanvas.height = rect.height * dpr;
      bgCanvas.style.width = `${rect.width}px`;
      bgCanvas.style.height = `${rect.height}px`;
      
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.scale(dpr, dpr);
      
      const bgCtx = bgCanvas.getContext('2d');
      if (bgCtx) {
        bgCtx.scale(dpr, dpr);
        drawPaperPattern(bgCtx, rect.width, rect.height, scrollY);
      }
      
      redrawAll();
    };
    
    setTimeout(resize, 10);
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [active, strokes, windowMode, size.w, size.h, currentPage, mode, scrollY]);

  const drawPaperPattern = (ctx: CanvasRenderingContext2D, width: number, height: number, sy: number) => {
    ctx.clearRect(0, 0, width, height);
    if (windowMode === 'fullscreen' && mode === 'transparent') return;
    
    ctx.save();
    ctx.translate(0, -sy);
    ctx.fillStyle = '#fefce8';
    ctx.fillRect(0, sy, width, height);

    ctx.globalAlpha = 0.4;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
    ctx.lineWidth = 1;

    switch (mode) {
      case 'lined': {
        const startY = Math.max(40, Math.floor(sy / 32) * 32);
        for (let y = startY; y < sy + height + 32; y += 32) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.3)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(60, sy);
        ctx.lineTo(60, sy + height);
        ctx.stroke();
        break;
      }
      case 'grid': {
        for (let x = 0; x < width; x += 24) {
          ctx.beginPath();
          ctx.moveTo(x, sy);
          ctx.lineTo(x, sy + height);
          ctx.stroke();
        }
        const startY = Math.floor(sy / 24) * 24;
        for (let y = startY; y < sy + height + 24; y += 24) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(width, y);
          ctx.stroke();
        }
        break;
      }
      case 'dotted': {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        const startY = Math.floor(sy / 24) * 24 + 12;
        for (let x = 12; x < width; x += 24) {
          for (let y = startY; y < sy + height + 24; y += 24) {
            ctx.beginPath();
            ctx.arc(x, y, 1.5, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        break;
      }
    }
    ctx.restore();
  };

  const redrawAll = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.scale(dpr, dpr);
    ctx.translate(0, -scrollY);
    ctx.restore();

    ctx.save();
    ctx.translate(0, -scrollY);
    for (const stroke of strokes) {
      drawStroke(ctx, stroke);
    }
    ctx.restore();
    if (currentStrokeRef.current) {
      ctx.save();
      ctx.translate(0, -scrollY);
      drawStroke(ctx, currentStrokeRef.current);
      ctx.restore();
    }
  }, [strokes, scrollY]);

  const drawStroke = (ctx: CanvasRenderingContext2D, stroke: Stroke) => {
    if (stroke.points.length === 0 || stroke.isSticker) return;

    ctx.save();
    if (stroke.isEraser) {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.fillStyle = 'rgba(0,0,0,1)';
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = stroke.color;
    }
    
    if (stroke.isHighlighter) {
      ctx.globalCompositeOperation = 'multiply';
      ctx.fillStyle = stroke.color;
    }

    try {
      const pointsArray = stroke.points.map(p => [p.x, p.y, p.pressure] as [number, number, number]);
      const outlinePoints = getStroke(pointsArray, {
        size: stroke.width,
        thinning: 0.5,
        smoothing: 0.5,
        streamline: 0.5,
        simulatePressure: false,
      });

      if (outlinePoints && outlinePoints.length > 0) {
        ctx.beginPath();
        ctx.moveTo(outlinePoints[0][0], outlinePoints[0][1]);
        for (let i = 1; i < outlinePoints.length; i++) {
          ctx.lineTo(outlinePoints[i][0], outlinePoints[i][1]);
        }
        ctx.closePath();
        ctx.fill();
      }
    } catch (e) {
      console.warn("Erro ao desenhar traço", e);
    }
    ctx.restore();
  };

  const eraseIntersectingStrokes = (x: number, y: number) => {
    const threshold = 15; // pixels
    const strokesToKeep: Stroke[] = [];
    const strokesToRemove: Stroke[] = [];
    
    for (const stroke of strokes) {
      const isHit = stroke.points.some(p => Math.hypot(p.x - x, p.y - y) < threshold);
      if (isHit) {
        strokesToRemove.push(stroke);
      } else {
        strokesToKeep.push(stroke);
      }
    }

    if (strokesToRemove.length > 0) {
      setStrokesByPage(prev => ({ ...prev, [currentPage]: strokesToKeep }));
      setRedoStackByPage(prev => ({
        ...prev,
        [currentPage]: [...(prev[currentPage] || []), ...strokesToRemove]
      }));
    }
  };

  const handlePointerDown = async (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('.whiteboard-toolbar') || (e.target as HTMLElement).closest('.whiteboard-sidebar')) {
      return;
    }
    setEditingPreset(null);
    e.preventDefault();
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = e.clientX - rect.left;
    const y = (e.clientY - rect.top) + scrollY;

    if (activeStamper) {
      const newStroke: Stroke = {
        points: [{ x, y, pressure: 0.5 }],
        color: 'transparent',
        width: 1,
        isEraser: false,
        isRewardSticker: true,
        rewardStickerId: activeStamper.stickerId,
        rewardCustomUrl: activeStamper.customUrl,
        rewardInstanceId: activeStamper.instanceId
      };
      setStrokesByPage(prev => ({
        ...prev,
        [currentPage]: [...(prev[currentPage] || []), newStroke]
      }));
      return;
    }

    if (tool === 'sticker') {
      setIsDrawing(false);
      const postitNumberStr = window.prompt("Digite o número do Post-it para linkar:");
      if (postitNumberStr) {
        const num = parseInt(postitNumberStr.replace(/\D/g, ''), 10);
        if (!isNaN(num)) {
          let stickerColor = '#fef08a';
          if (user) {
            try {
              const q = query(collection(db, 'users', user.uid, 'notes'), where('noteNumber', '==', num));
              const querySnapshot = await getDocs(q);
              if (!querySnapshot.empty) {
                stickerColor = querySnapshot.docs[0].data().color || '#fef08a';
              }
            } catch (e) {
              console.error("Erro ao buscar cor do post-it", e);
            }
          }
          const newStroke: Stroke = {
            points: [{ x, y, pressure: 0.5 }],
            color: stickerColor,
            width: 1,
            isEraser: false,
            isSticker: true,
            stickerNumber: num
          };
          setStrokesByPage(prev => ({
            ...prev,
            [currentPage]: [...(prev[currentPage] || []), newStroke]
          }));
        }
      }
      return;
    }

    setIsDrawing(true);
    
    isStraightLineRef.current = e.button === 2 || (e.buttons & 2) !== 0;

    const pressure = e.pressure !== undefined && e.pressure > 0 ? e.pressure : 0.5;

    if (tool === 'eraser' && activeEraser.type === 'stroke') {
      eraseIntersectingStrokes(x, y);
    } else {
      currentStrokeRef.current = {
        points: [{ x, y, pressure }],
        color: tool === 'eraser' ? '#000000' : color,
        width: tool === 'eraser' ? strokeWidth * 4 : strokeWidth,
        isEraser: tool === 'eraser',
        isHighlighter: tool === 'highlighter',
      };
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDrawing) return;
    e.preventDefault();

    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const pressure = e.pressure !== undefined && e.pressure > 0 ? e.pressure : 0.5;

    if (tool === 'eraser' && activeEraser.type === 'stroke') {
      eraseIntersectingStrokes(x, y);
    } else if (currentStrokeRef.current) {
      if (isStraightLineRef.current || (e.buttons & 2) !== 0) {
        if (currentStrokeRef.current.points.length > 1) {
          currentStrokeRef.current.points[1] = { x, y, pressure };
        } else {
          currentStrokeRef.current.points.push({ x, y, pressure });
        }
      } else {
        currentStrokeRef.current.points.push({ x, y, pressure });
      }
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = requestAnimationFrame(() => redrawAll());
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    e.preventDefault();
    setIsDrawing(false);

    if (currentStrokeRef.current && currentStrokeRef.current.points.length > 0) {
      const newStroke = currentStrokeRef.current;
      setStrokesByPage(prev => ({
        ...prev,
        [currentPage]: [...(prev[currentPage] || []), newStroke]
      }));
      setRedoStackByPage(prev => ({
        ...prev,
        [currentPage]: []
      }));
    }
    currentStrokeRef.current = null;
    redrawAll();
  };

  const handleUndo = () => {
    if (strokes.length === 0) return;
    setStrokesByPage(prev => {
      const pageStrokes = prev[currentPage] || [];
      const newStrokes = pageStrokes.slice(0, -1);
      const last = pageStrokes[pageStrokes.length - 1];
      setRedoStackByPage(r => ({ ...r, [currentPage]: [...(r[currentPage] || []), last] }));
      return { ...prev, [currentPage]: newStrokes };
    });
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    setRedoStackByPage(prev => {
      const pageRedo = prev[currentPage] || [];
      const last = pageRedo[pageRedo.length - 1];
      const newRedo = pageRedo.slice(0, -1);
      setStrokesByPage(s => ({ ...s, [currentPage]: [...(s[currentPage] || []), last] }));
      return { ...prev, [currentPage]: newRedo };
    });
  };

  const handleClear = () => {
    if (strokes.length === 0) return;
    if (!window.confirm('Limpar toda a lousa atual?')) return;
    setStrokesByPage(prev => ({ ...prev, [currentPage]: [] }));
    setRedoStackByPage(prev => ({ ...prev, [currentPage]: [] }));
  };

  const handleClose = () => setActive(false);
  const addNewPage = () => { 
    setTotalPages(p => p + 1); 
    setCurrentPage(totalPages + 1); 
    setScrollY(0);
  };
  
  const setPageWithScrollReset = (pageUpdater: (p: number) => number) => {
    setCurrentPage(p => {
      const newPage = pageUpdater(p);
      if (newPage !== p) setScrollY(0);
      return newPage;
    });
  };

  useEffect(() => {
    if (!active) return;
     const handler = (e: KeyboardEvent) => {
      // Escape e Ctrl+Z/Y sempre funcionam, mesmo em inputs
      if (e.key === 'Escape') handleClose();
      if (e.ctrlKey && e.key === 'z') { e.preventDefault(); handleUndo(); }
      if (e.ctrlKey && e.key === 'y') { e.preventDefault(); handleRedo(); }

      // Guard: Não acionar atalhos de tecla única enquanto estiver digitando
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;

      if (e.key === 'e') { setTool('eraser'); }
      if (e.key === 'p' || e.key === 'b') { setTool('pen'); }
      if (e.key === 'h' || e.key === 'm') { setTool('highlighter'); }
      if (e.shiftKey && e.key.toLowerCase() === 'l') {
        e.preventDefault();
        handleClear();
      }

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setScrollY(y => Math.max(0, y - 100));
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setScrollY(y => y + 100);
      }
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setPageWithScrollReset(p => Math.max(1, p - 1));
      }
      if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (currentPage === totalPages) {
          addNewPage();
        } else {
          setPageWithScrollReset(p => Math.min(totalPages, p + 1));
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [active, strokes, currentPage, totalPages]);

  const onResizeStart = (e: React.PointerEvent) => {
    e.preventDefault(); e.stopPropagation();
    const el = e.currentTarget as HTMLElement;
    el.setPointerCapture(e.pointerId);
    resizeRef.current = { startX: e.clientX, startY: e.clientY, startW: size.w, startH: size.h };
  };

  const onResizeMove = (e: React.PointerEvent) => {
    if (!resizeRef.current) return;
    e.preventDefault();
    const dx = e.clientX - resizeRef.current.startX;
    const dy = e.clientY - resizeRef.current.startY;
    setSize({ w: Math.max(300, resizeRef.current.startW + dx), h: Math.max(300, resizeRef.current.startH + dy) });
  };

  const onResizeEnd = (e: React.PointerEvent) => {
    resizeRef.current = null;
    (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    localStorage.setItem('wb_size', JSON.stringify(size));
  };

  if (!active) return null;

  const content = (
    <>
      {windowMode === 'fullscreen' && mode === 'transparent' && (
        <div className="absolute inset-0 bg-transparent pointer-events-none" />
      )}

      <canvas
        ref={bgCanvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ touchAction: 'none' }}
      />
      <canvas
        ref={canvasRef}
        className={`absolute inset-0 ${tool === 'pointer' ? 'pointer-events-none' : 'cursor-crosshair'}`}
        style={{ touchAction: 'none' }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onContextMenu={(e) => e.preventDefault()}
      />
      
      {strokes.filter(s => s.isSticker && s.points && s.points.length > 0).map((s, idx) => (
        <StickerNode
          key={`sticker-${idx}`}
          s={s}
          scrollY={scrollY}
          onStop={(_e: any, data: any) => {
            const updatedStrokes = strokes.map(stroke => 
              stroke === s ? { ...stroke, points: [{ x: data.x, y: data.y + scrollY, pressure: stroke.points[0]?.pressure || 0.5 }] } : stroke
            );
            setStrokesByPage(prev => ({ ...prev, [currentPage]: updatedStrokes }));
          }}
          onDelete={(e: any) => {
            e.preventDefault();
            e.stopPropagation();
            if (window.confirm("Excluir este adesivo?")) {
              const updatedStrokes = strokes.filter(stroke => stroke !== s);
              setStrokesByPage(prev => ({ ...prev, [currentPage]: updatedStrokes }));
            }
          }}
          onContextMenu={(e: any) => e.preventDefault()}
          onEdit={async (e: any) => {
            e.stopPropagation();
            const newNumStr = window.prompt("Editar número do Post-it linkado:", s.stickerNumber?.toString());
            if (newNumStr) {
              const num = parseInt(newNumStr.replace(/\D/g, ''), 10);
              if (!isNaN(num)) {
                let newColor = s.color;
                if (user) {
                  try {
                    const q = query(collection(db, 'users', user.uid, 'notes'), where('noteNumber', '==', num));
                    const querySnapshot = await getDocs(q);
                    if (!querySnapshot.empty) {
                      newColor = querySnapshot.docs[0].data().color || '#fef08a';
                    }
                  } catch (err: any) {}
                }
                const updatedStrokes = strokes.map(stroke => 
                  stroke === s ? { ...stroke, stickerNumber: num, color: newColor } : stroke
                );
                setStrokesByPage(prev => ({ ...prev, [currentPage]: updatedStrokes }));
              }
            }
          }}
        />
      ))}

      {strokes.filter(s => s.isRewardSticker && s.points && s.points.length > 0).map((s, idx) => {
        const url = s.rewardCustomUrl || STICKERS_DEFS[s.rewardStickerId || ''];
        if (!url) return null;
        return (
          <div
            key={`reward-sticker-${idx}`}
            className="absolute pointer-events-none"
            style={{
              left: s.points[0].x,
              top: s.points[0].y - scrollY,
              transform: 'translate(-50%, -50%)',
            }}
          >
            <img 
              src={url} 
              alt="Adesivo" 
              className="w-24 h-24 object-contain drop-shadow-md opacity-90" 
            />
          </div>
        );
      })}

      {/* Transparent Custom Sidebar */}
      {sidebarMode !== 'hidden' && (
        <div className={`whiteboard-sidebar pointer-events-auto absolute z-[9999] ${sidebarMode === 'fixed' ? 'left-2 top-1/2 -translate-y-1/2' : 'left-4 top-20'}`}>
          <Draggable disabled={sidebarMode === 'fixed'} handle=".sidebar-drag" nodeRef={sidebarRef}>
            <div ref={sidebarRef} className="flex flex-col items-center gap-1 p-1.5 bg-white/40 dark:bg-gray-800/40 backdrop-blur-md rounded-2xl shadow-xl border border-white/50 dark:border-gray-700/50">
              {sidebarMode === 'floating' && (
                <div className="sidebar-drag w-full flex justify-center py-1 cursor-grab active:cursor-grabbing text-gray-400 drop-shadow-md">
                  <GripHorizontal className="w-4 h-4" />
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-1 w-full place-items-center">
                {/* Close Button */}
                <button onClick={handleClose} className="w-8 h-8 rounded-full flex items-center justify-center transition-all bg-red-100 text-red-600 hover:bg-red-200 shadow-sm" title="Fechar Lousa">
                  <X className="w-4 h-4" />
                </button>
                
                {/* Window Mode */}
                <button
                  onClick={() => {
                    const nextMode = windowMode === 'fullscreen' ? 'floating' : 'fullscreen';
                    setWindowMode(nextMode);
                    if (nextMode === 'floating' && mode === 'transparent') setMode('lined');
                  }}
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-all bg-white/90 shadow-sm text-gray-500 hover:text-indigo-600"
                  title={windowMode === 'fullscreen' ? 'Modo Janela' : 'Tela Cheia'}
                >
                  {windowMode === 'fullscreen' ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>

                {/* Background Mode */}
                <div className="relative group">
                  <button className={`w-8 h-8 rounded-full flex items-center justify-center transition-all shadow-sm ${mode === 'transparent' ? 'bg-indigo-100 text-indigo-600 ring-2 ring-indigo-400' : 'bg-white/90 text-gray-500 hover:text-indigo-600'}`} title="Fundo / Modo">
                    {mode === 'transparent' ? <Focus className="w-4 h-4" /> : <PanelTop className="w-4 h-4" />}
                  </button>
                  <div className="absolute left-full ml-3 top-0 hidden group-hover:flex bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 p-2 flex-col gap-1 z-[10000] w-40">
                    <button onClick={() => { setMode('transparent'); setWindowMode('fullscreen'); }} className={`text-xs p-1.5 rounded text-left ${mode === 'transparent' ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-gray-50'}`}> Lousa Transparente</button>
                    <button onClick={() => setMode('lined')} className={`text-xs p-1.5 rounded text-left ${mode === 'lined' ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-gray-50'}`}> 📝 Pautado</button>
                    <button onClick={() => setMode('grid')} className={`text-xs p-1.5 rounded text-left ${mode === 'grid' ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-gray-50'}`}> 📐 Quadriculado</button>
                    <button onClick={() => setMode('dotted')} className={`text-xs p-1.5 rounded text-left ${mode === 'dotted' ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-gray-50'}`}> 📌 Pontilhado</button>
                  </div>
                </div>

                {/* Mouse / Pointer Tool */}
                <button onClick={() => setTool('pointer')} className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${tool === 'pointer' ? 'bg-indigo-50 text-indigo-600 ring-2 ring-indigo-400' : 'bg-white/90 shadow-sm text-gray-500 hover:text-indigo-600'}`} title="Mouse (Atalho: V ou Esc)">
                  <MousePointer2 className="w-4 h-4" />
                </button>

                {/* Sticker Tool */}
                <button onClick={() => setTool('sticker')} className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${tool === 'sticker' ? 'bg-yellow-50 text-yellow-600 ring-2 ring-yellow-400' : 'bg-white/90 shadow-sm text-gray-500 hover:text-yellow-600'}`} title="Linkar Post-it">
                  <span className="text-lg">📌</span>
                </button>

                {/* Notebooks Menu */}
                <button onClick={() => setShowNotebooksManager(true)} className="w-8 h-8 rounded-full flex items-center justify-center transition-all bg-white/90 shadow-sm text-gray-500 hover:text-purple-600" title="Alterar Caderno">
                  <Book className="w-4 h-4" />
                </button>

                {/* Clear Board */}
                <button onClick={handleClear} className="w-8 h-8 rounded-full flex items-center justify-center transition-all bg-white/90 shadow-sm text-red-500 hover:text-red-600 hover:bg-red-50" title="Limpar Lousa">
                  <Trash2 className="w-4 h-4" />
                </button>

                {/* Undo / Redo */}
                <button onClick={handleUndo} disabled={strokes.length === 0} className="w-8 h-8 rounded-full bg-white/90 shadow-sm flex items-center justify-center text-gray-500 hover:text-indigo-600 disabled:opacity-30"><Undo2 className="w-4 h-4" /></button>
                <button onClick={handleRedo} disabled={redoStack.length === 0} className="w-8 h-8 rounded-full bg-white/90 shadow-sm flex items-center justify-center text-gray-500 hover:text-indigo-600 disabled:opacity-30"><Redo2 className="w-4 h-4" /></button>
              </div>

              <div className="w-full h-px bg-gray-300 dark:bg-gray-600 my-1 drop-shadow-md" />

              {/* PENS GRID */}
              <div className="grid grid-cols-2 gap-1 w-full place-items-center">
                {penPresets.map((preset) => (
                  <div key={preset.id} className="relative group">
                    <button
                      onClick={() => {
                        if (activePenId === preset.id && tool === 'pen') setEditingPreset(editingPreset === preset.id ? null : preset.id);
                        else { setTool('pen'); setActivePenId(preset.id); setEditingPreset(null); }
                      }}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-all drop-shadow-md ${tool === 'pen' && activePenId === preset.id ? 'ring-2 ring-indigo-500 scale-110' : 'opacity-80 hover:opacity-100'}`}
                      style={{ backgroundColor: preset.color }}
                    >
                      <div className="bg-white/40 rounded-full" style={{ width: Math.min(preset.width, 12), height: Math.min(preset.width, 12) }} />
                    </button>
                    {editingPreset === preset.id && tool === 'pen' && (
                      <div className="absolute left-full ml-3 top-0 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 p-2 flex flex-col gap-2 z-[10000]">
                        <div className="flex gap-1 flex-wrap w-24">
                          {COLORS.map(c => (
                            <button key={c} onClick={() => updatePenPreset(preset.id, { color: c })} className={`w-5 h-5 rounded-full border-2 ${preset.color === c ? 'border-indigo-500 scale-110' : 'border-gray-300'}`} style={{ backgroundColor: c }} />
                          ))}
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => updatePenPreset(preset.id, { width: Math.max(1, preset.width - 2) })}><Minus className="w-4 h-4" /></button>
                          <span className="text-xs font-bold w-6 text-center">{preset.width}</span>
                          <button onClick={() => updatePenPreset(preset.id, { width: Math.min(30, preset.width + 2) })}><Plus className="w-4 h-4" /></button>
                        </div>
                        {penPresets.length > 1 && (
                          <button onClick={() => deletePenPreset(preset.id)} className="flex items-center gap-1 text-xs text-red-500 hover:bg-red-50 rounded p-1 mt-1"><Trash2 className="w-3 h-3" /> Excluir</button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                {penPresets.length < 5 && (
                  <button onClick={addPenPreset} className="w-7 h-7 rounded-full bg-white/80 border border-gray-200 text-gray-500 hover:text-indigo-600 flex items-center justify-center shadow-sm backdrop-blur-sm"><Plus className="w-4 h-4" /></button>
                )}
              </div>

              <div className="w-full h-px bg-gray-300 dark:bg-gray-600 my-1 drop-shadow-md" />
              

              <div className="w-full h-px bg-gray-300 dark:bg-gray-600 my-1 drop-shadow-md" />

              {/* HIGHLIGHTERS GRID */}
              <div className="grid grid-cols-2 gap-1 w-full place-items-center">
                {highlighterPresets.map((preset) => (
                  <div key={preset.id} className="relative group">
                    <button
                      onClick={() => {
                        if (activeHighlighterId === preset.id && tool === 'highlighter') setEditingPreset(editingPreset === preset.id ? null : preset.id);
                        else { setTool('highlighter'); setActiveHighlighterId(preset.id); setEditingPreset(null); }
                      }}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-all drop-shadow-md ${tool === 'highlighter' && activeHighlighterId === preset.id ? 'ring-2 ring-yellow-400 scale-110' : 'opacity-80 hover:opacity-100'}`}
                      style={{ backgroundColor: preset.color }}
                      title="Marcador"
                    >
                      <Highlighter className="w-4 h-4 text-gray-800 opacity-60" />
                    </button>
                    {editingPreset === preset.id && tool === 'highlighter' && (
                      <div className="absolute left-full ml-3 top-0 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 p-2 flex flex-col gap-2 z-[10000]">
                        <div className="flex gap-1 flex-wrap w-24">
                          {['#fef08a', '#fbcfe8', '#bfdbfe', '#bbf7d0', '#e9d5ff', '#ffedd5'].map(c => (
                            <button key={c} onClick={() => updateHighlighterPreset(preset.id, { color: c })} className={`w-5 h-5 rounded-full border-2 ${preset.color === c ? 'border-indigo-500 scale-110' : 'border-gray-300'}`} style={{ backgroundColor: c }} />
                          ))}
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => updateHighlighterPreset(preset.id, { width: Math.max(10, preset.width - 4) })}><Minus className="w-4 h-4" /></button>
                          <span className="text-xs font-bold w-6 text-center">{preset.width}</span>
                          <button onClick={() => updateHighlighterPreset(preset.id, { width: Math.min(60, preset.width + 4) })}><Plus className="w-4 h-4" /></button>
                        </div>
                        {highlighterPresets.length > 1 && (
                          <button onClick={() => deleteHighlighterPreset(preset.id)} className="flex items-center gap-1 text-xs text-red-500 hover:bg-red-50 rounded p-1 mt-1"><Trash2 className="w-3 h-3" /> Excluir</button>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                {highlighterPresets.length < 5 && (
                  <button onClick={addHighlighterPreset} className="w-7 h-7 rounded-full bg-white/80 border border-gray-200 text-gray-500 hover:text-yellow-600 flex items-center justify-center shadow-sm backdrop-blur-sm" title="Adicionar Marcador"><Plus className="w-4 h-4" /></button>
                )}
              </div>

              {/* ERASERS GRID */}
              <div className="grid grid-cols-2 gap-1 w-full place-items-center">
                {eraserPresets.map((preset) => (
                  <div key={preset.id} className="relative group">
                    <button
                      onClick={() => {
                        if (activeEraserId === preset.id && tool === 'eraser') setEditingPreset(editingPreset === preset.id ? null : preset.id);
                        else { setTool('eraser'); setActiveEraserId(preset.id); setEditingPreset(null); }
                      }}
                      className={`w-8 h-8 rounded-full flex items-center justify-center bg-white/90 shadow-md backdrop-blur-sm transition-all ${tool === 'eraser' && activeEraserId === preset.id ? 'ring-2 ring-pink-500 text-pink-600 scale-110' : 'text-gray-600 hover:text-pink-500'}`}
                    >
                      {preset.type === 'stroke' ? <Focus className="w-4 h-4" /> : <Eraser className="w-4 h-4" />}
                    </button>
                    {editingPreset === preset.id && tool === 'eraser' && (
                      <div className="absolute left-full ml-3 top-0 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 p-2 flex flex-col gap-2 z-[10000] w-40">
                        <select value={preset.type} onChange={e => updateEraserPreset(preset.id, { type: e.target.value as 'normal' | 'stroke' })} className="text-xs p-1 rounded border">
                          <option value="normal">Borracha Normal</option>
                          <option value="stroke">Apagar Traços</option>
                        </select>
                        {preset.type === 'normal' && (
                          <div className="flex items-center justify-center gap-2 mt-1">
                            <button onClick={() => updateEraserPreset(preset.id, { width: Math.max(4, preset.width - 4) })}><Minus className="w-4 h-4" /></button>
                            <span className="text-xs font-bold w-6 text-center">{preset.width}</span>
                            <button onClick={() => updateEraserPreset(preset.id, { width: Math.min(50, preset.width + 4) })}><Plus className="w-4 h-4" /></button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
                {eraserPresets.length < 2 && (
                  <button onClick={addEraserPreset} className="w-7 h-7 rounded-full bg-white/80 border border-gray-200 text-gray-500 hover:text-pink-600 flex items-center justify-center shadow-sm backdrop-blur-sm"><Plus className="w-4 h-4" /></button>
                )}
              </div>

              <div className="w-full h-px bg-gray-300 dark:bg-gray-600 my-1 drop-shadow-md" />

              {/* Bottom Row */}
              <div className="grid grid-cols-2 gap-1 w-full place-items-center relative group">
                <div className="relative group col-span-2 flex justify-center w-full">
                  <button className="w-full max-w-[4rem] h-8 rounded-full bg-indigo-50 shadow-sm flex items-center justify-center text-indigo-600 text-xs font-bold ring-1 ring-indigo-200">
                    Pág {currentPage}
                  </button>
                  <div className="absolute left-full ml-3 top-1/2 -translate-y-1/2 hidden group-hover:flex bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 p-1 items-center gap-1 z-[10000]">
                    <button onClick={() => setPageWithScrollReset(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="p-1.5 text-gray-600 disabled:opacity-30 hover:bg-gray-200 rounded"><ChevronLeft className="w-4 h-4" /></button>
                    <span className="text-xs font-bold w-12 text-center text-gray-700 dark:text-gray-300">Pág {currentPage}</span>
                    <button onClick={() => setPageWithScrollReset(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="p-1.5 text-gray-600 disabled:opacity-30 hover:bg-gray-200 rounded"><ChevronRight className="w-4 h-4" /></button>
                    <div className="w-px h-4 bg-gray-300 mx-1" />
                    <button onClick={addNewPage} className="p-1.5 text-indigo-600 hover:bg-indigo-100 rounded" title="Nova Página"><FilePlus className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>

              {/* Settings Toggle */}
              <div className="relative mt-1 w-full flex justify-center">
                <button onClick={() => setShowSidebarSettings(!showSidebarSettings)} className={`w-8 h-8 rounded-full shadow-md backdrop-blur-sm flex items-center justify-center transition-all ${showSidebarSettings ? 'bg-indigo-50 text-indigo-600 ring-2 ring-indigo-400' : 'bg-white/90 text-gray-500 hover:text-indigo-600'}`}>
                  <Settings2 className="w-4 h-4" />
                </button>
                {showSidebarSettings && (
                  <div className="absolute left-full ml-3 bottom-0 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 p-2 flex flex-col gap-1 z-[10000] w-36">
                    <button onClick={() => { setSidebarMode('fixed'); saveSettings(penPresets, highlighterPresets, eraserPresets, 'fixed'); setShowSidebarSettings(false); }} className={`text-xs p-1.5 rounded text-left ${sidebarMode === 'fixed' ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-gray-50'}`}> Sidebar Fixa</button>
                    <button onClick={() => { setSidebarMode('floating'); saveSettings(penPresets, highlighterPresets, eraserPresets, 'floating'); setShowSidebarSettings(false); }} className={`text-xs p-1.5 rounded text-left ${sidebarMode === 'floating' ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-gray-50'}`}> Sidebar Flutuante</button>
                    <button onClick={() => { setSidebarMode('hidden'); saveSettings(penPresets, highlighterPresets, eraserPresets, 'hidden'); setShowSidebarSettings(false); }} className={`text-xs p-1.5 rounded text-left text-red-500 hover:bg-red-50`}> Ocultar Sidebar</button>
                  </div>
                )}
              </div>
            </div>
          </Draggable>
        </div>
      )}

      {/* Recover hidden sidebar button */}
      {sidebarMode === 'hidden' && (
        <button
          onClick={() => { setSidebarMode('floating'); saveSettings(penPresets, highlighterPresets, eraserPresets, 'floating'); }}
          className="whiteboard-toolbar pointer-events-auto absolute top-4 right-4 z-[9999] w-10 h-10 rounded-full bg-white/90 shadow-lg flex items-center justify-center text-gray-600 hover:bg-white"
          title="Mostrar Menu da Lousa"
        >
          <PanelTop className="w-5 h-5" />
        </button>
      )}

      {/* Resize Handle for Floating Window */}
      {windowMode === 'floating' && (
        <div
          className="absolute bottom-0 right-0 w-10 h-10 cursor-nwse-resize flex items-end justify-end p-2 opacity-50 hover:opacity-100 whiteboard-toolbar"
          onPointerDown={onResizeStart}
          onPointerMove={onResizeMove}
          onPointerUp={onResizeEnd}
          onPointerCancel={onResizeEnd}
          style={{ touchAction: 'none', zIndex: 10000 }}
        >
          <div className="w-4 h-4 border-r-2 border-b-2 border-gray-500 dark:border-gray-400" />
        </div>
      )}

      {/* Notebooks Manager Modal */}
      {showNotebooksManager && (
        <NotebooksManager 
          onClose={() => setShowNotebooksManager(false)} 
          onSelectNotebook={(nb) => {
            setActiveNotebook(nb);
            setShowNotebooksManager(false);
            // reset strokes array to empty or load from Firebase (to be implemented)
            setStrokesByPage({ 1: [] });
            setRedoStackByPage({ 1: [] });
            setCurrentPage(1);
            setTotalPages(nb.totalPages || 1);
          }} 
        />
      )}
    </>
  );

  const handleWheel = (e: React.WheelEvent) => {
    if (mode === 'transparent') return;
    // Intercept scroll event to scroll notebook instead of the app
    e.stopPropagation();
    setScrollY(y => Math.max(0, y + e.deltaY));
  };

  if (windowMode === 'fullscreen') {
    return createPortal(
      <div 
        ref={containerRef}
        className={`fixed inset-0 z-[9998] ${mode !== 'transparent' ? 'bg-[#fefce8]' : ''} ${tool === 'pointer' && mode === 'transparent' ? 'pointer-events-none' : ''}`} 
        style={{ touchAction: 'none' }}
        onWheel={handleWheel}
      >
        {content}
      </div>,
      document.body
    );
  }

  // Modo Caderninho Flutuante
  return createPortal(
    <div className="fixed inset-0 z-[9998] pointer-events-none">
      <Draggable 
        nodeRef={containerRef} 
        handle=".whiteboard-drag-handle" 
        bounds="parent" 
        defaultPosition={savedPos || {x: 0, y: 0}}
        onStop={(_e, data) => localStorage.setItem('wb_pos', JSON.stringify({ x: data.x, y: data.y }))}
      >
        <div 
          ref={containerRef}
          className="absolute pointer-events-auto bg-[#fefce8] rounded-xl shadow-2xl overflow-hidden border border-gray-300 dark:border-gray-600 flex flex-col"
          style={{ width: `${size.w}px`, height: `${size.h}px`, touchAction: 'none' }}
          onWheel={handleWheel}
        >
          <div 
            className={`whiteboard-drag-handle whiteboard-toolbar h-8 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between px-3 cursor-grab active:cursor-grabbing ${!activeNotebook ? 'bg-indigo-50 dark:bg-gray-800' : ''}`}
            style={activeNotebook ? { backgroundColor: activeNotebook.coverColor, color: '#ffffff' } : {}}
          >
            <div className="flex items-center gap-2">
              <GripHorizontal className={`w-4 h-4 ${activeNotebook ? 'text-white/80' : 'text-gray-400'}`} />
              <span className={`text-xs font-bold uppercase tracking-wider truncate max-w-[200px] sm:max-w-xs ${activeNotebook ? 'text-white' : 'text-gray-600 dark:text-gray-300'}`}>
                {activeNotebook ? `Caderno Digital de ${activeNotebook.name}` : 'Rascunho Rápido'}
              </span>
            </div>
            <button onClick={handleClose} className={`p-1 rounded ${activeNotebook ? 'text-white hover:bg-white/20' : 'hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-500'}`}>
              <X className="w-4 h-4" />
            </button>
          </div>



          <div className="relative flex-1">
            {content}
          </div>
        </div>
      </Draggable>
    </div>,
    document.body
  );
}

function StickerNode({ s, zoom = 1, scrollY = 0, onStop, onDelete, onEdit }: any) {
  const nodeRef = useRef<HTMLDivElement>(null);
  const { user } = useAuth();
  const [noteData, setNoteData] = useState<any>(null);
  const [isFlipped, setIsFlipped] = useState(false);

  useEffect(() => {
    if (!user || !s.stickerNumber) return;
    const q = query(collection(db, 'users', user.uid, 'notes'), where('noteNumber', '==', s.stickerNumber));
    const unsub = onSnapshot(q, (snap) => {
      if (!snap.empty) {
        setNoteData(snap.docs[0].data());
      }
    });
    return () => unsub();
  }, [user, s.stickerNumber]);

  const isFlashcard = noteData?.isFlashcard;

  if (isFlashcard) {
    return (
      <Draggable
        nodeRef={nodeRef}
        position={{ x: s.points[0].x * zoom, y: s.points[0].y * zoom - scrollY }}
        onStop={onStop}
      >
        <div ref={nodeRef} className="absolute top-0 left-0 z-50 cursor-move" style={{ width: '160px', height: '110px' }}>
          <div 
            className="w-full h-full relative group" 
            style={{ perspective: '1000px' }}
            onContextMenu={onDelete}
            onDoubleClick={onEdit}
            onClick={(e) => { e.stopPropagation(); setIsFlipped(!isFlipped); }}
            title="Clique para virar o cartão. Duplo-clique para editar. Botão direito para excluir."
          >
            <div 
              className="w-full h-full absolute top-0 left-0 transition-transform duration-500 rounded-lg shadow-lg border border-gray-200 overflow-hidden cursor-pointer"
              style={{
                transformStyle: 'preserve-3d',
                transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
                backgroundColor: s.color || '#fef08a'
              }}
            >
              {/* Front */}
              <div 
                className="absolute inset-0 w-full h-full p-3 flex flex-col items-center justify-center bg-white/40 pointer-events-none"
                style={{ backfaceVisibility: 'hidden' }}
              >
                <div className="text-[10px] font-bold text-gray-500 mb-1">FRENTE #{s.stickerNumber}</div>
                <div className="text-xs font-semibold text-gray-800 line-clamp-3 text-center" dangerouslySetInnerHTML={{ __html: noteData?.content || '...' }} />
              </div>

              {/* Back */}
              <div 
                className="absolute inset-0 w-full h-full p-3 flex flex-col items-center justify-center bg-indigo-50 pointer-events-none"
                style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
              >
                <div className="text-[10px] font-bold text-indigo-500 mb-1">VERSO</div>
                <div className="text-xs font-semibold text-gray-800 line-clamp-3 text-center" dangerouslySetInnerHTML={{ __html: noteData?.backContent || '...' }} />
              </div>
            </div>
          </div>
        </div>
      </Draggable>
    );
  }

  return (
    <Draggable
      nodeRef={nodeRef}
      position={{ x: s.points[0].x * zoom, y: s.points[0].y * zoom - scrollY }}
      onStop={onStop}
    >
      <div ref={nodeRef} className="absolute top-0 left-0 z-50 cursor-move">
        <button
          onClick={() => window.dispatchEvent(new CustomEvent('open-postit', { detail: s.stickerNumber }))}
          onContextMenu={onDelete}
          onDoubleClick={onEdit}
          className="hover:scale-110 transition-transform text-gray-800 px-3 py-1.5 rounded-md shadow-md border border-black/10 font-bold text-sm flex items-center gap-1 group"
          style={{ backgroundColor: s.color || '#fef08a' }}
          title={`Duplo-clique para editar. Botão direito para excluir.`}
        >
          📌 #{s.stickerNumber}
        </button>
      </div>
    </Draggable>
  );
}
